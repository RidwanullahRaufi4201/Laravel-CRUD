<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;


class studentController extends Controller
{
    public function create(Request $req)
    {
           $validate=$req->validate([
              'firstname'=>['required','min:3'],
              'lastname'=>['required','min:3'],
              'username'=>['required','min:6'],
              'email'=>'required',
              'password'=>['required','min:5'],
           ]);
            DB::table('students')->insert([
               'firstname'=>$req->firstname,
               'lastname'=>$req->lastname,
               'username'=>$req->username,
               'email'=>$req->email,
               'password'=>$req->password,
            ]);   
        return redirect(route('index'))->with('status','record Added Successfully !');
    }

    public function index()
    {
          $students=DB::table('students')->get();
        return view('CRUD',['students'=>$students]);
    }

    public function edit($id)
    {
           $student=DB::table('students')->find($id);
           return view('Edit',['student'=>$student]);
    }

    public function update(Request $req,$id)
    {

        $validate=$req->validate([
            'firstname'=>['required','min:3'],
            'lastname'=>['required','min:3'],
            'username'=>['required','min:6'],
            'email'=>'required',
            'password'=>['required','min:5'],
         ]);
        DB::table('students')->where('id',$id)->update([
            'firstname'=>$req->firstname,
            'lastname'=>$req->lastname,
            'username'=>$req->username,
            'email'=>$req->email,
            'password'=>$req->password,
        ]);

        return redirect(route('index'))->with('status','your record updated successfully');

    }

    public function delete($id)
    {
        DB::table('students')->where('id',$id)->delete();
        return redirect(route('index'))->with('status','your record deleted successfully');
    }
}
