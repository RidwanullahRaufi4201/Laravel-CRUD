<?php

use Illuminate\Support\Facades\Route;

use App\Http\Controllers\studentController;

Route::get('/', [studentController::class,'index'])->name('index');
Route::post('/', [studentController::class,'create']);
Route::get('/edit/{id}', [studentController::class,'edit']);
Route::post('/edit/{id}',[studentController::class,'update']);

Route::get('delete/{id}',[studentController::class,'delete']);
