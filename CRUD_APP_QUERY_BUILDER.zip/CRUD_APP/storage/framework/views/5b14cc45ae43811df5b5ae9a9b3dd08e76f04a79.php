<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD IN QUERY BUILDER</title>
</head>
<body>
    <div class="container-fluid bg-success p-3">
         <div class="row">
            <div class="col-md-12">
                <h5 class="text-center text-white">CRUD IN LARAVEL USING QUERY BUILDER</h5>
                <p class="text-center m-2 text-white">Edit Page</p>
            </div>
         </div>
    </div>
      <div class="container">
    
            <div class="row justify-content-center">
                <div class="col-md-8 m-2">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">FirstName</label>
                              <input type="text" name="firstname" value="<?php echo e($student->firstname); ?>" class="form-control">
                                  <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class=" text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">LastName</label>
                              <input type="text" name="lastname" value="<?php echo e($student->lastname); ?>" class="form-control">
                              <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Username</label>
                              <input type="text" name="username" value="<?php echo e($student->username); ?>" class="form-control">
                              <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Email</label>
                              <input type="email" name="email" value="<?php echo e($student->email); ?>" class="form-control">
                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Pasword</label>
                              <input type="password" value="<?php echo e($student->password); ?>" name="password" class="form-control">
                              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group mt-2">
                    
                              <input type="submit" name="submit" value="SUBMIT" class="form-control bg-success text-white">
                        </div>
                    
                 
                </div>
               
            </div>
      </div>
</body>
</html><?php /**PATH C:\Users\Ridwanullah Raufi\Desktop\LaravelPractice\CRUD_APP\resources\views/Edit.blade.php ENDPATH**/ ?>