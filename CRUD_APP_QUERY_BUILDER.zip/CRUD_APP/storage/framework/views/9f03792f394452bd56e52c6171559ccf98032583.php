<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/bootstrap.min.css')); ?>">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>CRUD IN QUERY BUILDER</title>
</head>
<body>
    <div class="container-fluid bg-success p-3">
         <div class="row">
            <div class="col-md-12">
                <h5 class="text-center text-white">CRUD IN LARAVEL USING QUERY BUILDER</h5>
            </div>
         </div>
    </div>
      <div class="container">
    
            <div class="row">
                <div class="col-md-4 m-2">
                    <form action="" method="post">
                        <?php echo csrf_field(); ?>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">FirstName</label>
                              <input type="text" name="firstname" class="form-control">
                                  <?php $__errorArgs = ['firstname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class=" text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">LastName</label>
                              <input type="text" name="lastname" class="form-control">
                              <?php $__errorArgs = ['lastname'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Username</label>
                              <input type="text" name="username" class="form-control">
                              <?php $__errorArgs = ['username'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Email</label>
                              <input type="email" name="email" class="form-control">
                              <?php $__errorArgs = ['email'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group">
                              <label for="" class="form-text fw-bold mb-1">Pasword</label>
                              <input type="password" name="password" class="form-control">
                              <?php $__errorArgs = ['password'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <p class="text-danger">
                                        <?php echo e($message); ?>

                                    </p>
                                  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                              
                        </div>
                        <div class="form-group mt-2">
                    
                              <input type="submit" name="submit" value="SUBMIT" class="form-control bg-success text-white">
                        </div>
                    </form>
                    <?php if(session()->has('status')): ?>
                       <div class="alert alert-success mt-2">
                          <?php echo e(session('status')); ?>

                       </div>
                    <?php endif; ?>
                </div>
                <div class="col-md-4 mt-4">
                  <table class="table table-striped">
                              <tr>
                                <th>FirstName</th>
                                <th>LastName</th>
                                <th>Username</th>
                                <th>Email</th>
                                <th>Password</th>
                                <th>Action</th>
                              </tr>

                              <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                 <tr>
                                      <td><?php echo e($student->firstname); ?></td>
                                      <td><?php echo e($student->lastname); ?></td>
                                      <td><?php echo e($student->username); ?></td>
                                      <td><?php echo e($student->email); ?></td>
                                      <td><?php echo e($student->password); ?></td>
                                      <td class=" d-flex">
                                         <a href="<?php echo e(url('/edit',$student->id)); ?>" class="btn  btn-success">Edit</a>
                                         <a href="<?php echo e(url('/delete',$student->id)); ?>" class="btn btn-danger">Delete</a>
                                      </td>
                                 </tr>
                              <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </table>
                </div>
            </div>
      </div>
</body>
</html><?php /**PATH C:\Users\Ridwanullah Raufi\Desktop\LaravelPractice\CRUD_APP\resources\views/CRUD.blade.php ENDPATH**/ ?>